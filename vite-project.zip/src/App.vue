<script setup lang="ts">

</script>

<template>
<section>
  <meta name="referrer" content="no-referrer">
  <router-view />
</section>

</template>

<style>
</style>
